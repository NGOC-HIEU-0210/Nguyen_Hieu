package com.hieu.airline_core_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineCoreServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
