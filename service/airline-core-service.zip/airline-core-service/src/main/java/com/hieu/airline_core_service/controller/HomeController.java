package com.hieu.airline_core_service.controller;

import com.hieu.payload.response.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
    @GetMapping
    public ApiResponse HomeController(){
        ApiResponse apiResponse = new ApiResponse("Hey bro");
        return apiResponse;
    }
}

